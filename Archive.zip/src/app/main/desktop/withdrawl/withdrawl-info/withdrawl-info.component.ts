import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawl-info',
  templateUrl: './withdrawl-info.component.html',
  styleUrl: './withdrawl-info.component.css'
})
export class WithdrawlInfoComponent {

}
