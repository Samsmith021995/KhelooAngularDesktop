import { Component } from '@angular/core';

@Component({
  selector: 'app-affiliate',
  templateUrl: './affiliate.component.html',
  styleUrl: './affiliate.component.css'
})
export class AffiliateComponent {

}
