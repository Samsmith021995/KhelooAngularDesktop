import { Component } from '@angular/core';

@Component({
  selector: 'app-disconnection-policy',
  templateUrl: './disconnection-policy.component.html',
  styleUrl: './disconnection-policy.component.css'
})
export class DisconnectionPolicyComponent {

}
