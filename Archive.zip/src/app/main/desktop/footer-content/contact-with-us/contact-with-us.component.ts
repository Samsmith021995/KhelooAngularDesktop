import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-with-us',
  templateUrl: './contact-with-us.component.html',
  styleUrl: './contact-with-us.component.css'
})
export class ContactWithUsComponent {

}
