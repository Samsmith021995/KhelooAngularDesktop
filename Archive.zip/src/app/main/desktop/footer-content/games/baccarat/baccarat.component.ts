import { Component } from '@angular/core';

@Component({
  selector: 'app-baccarat',
  templateUrl: './baccarat.component.html',
  styleUrl: './baccarat.component.css'
})
export class BaccaratComponent {

}
