import { Component } from '@angular/core';

@Component({
  selector: 'app-andar-bahar',
  templateUrl: './andar-bahar.component.html',
  styleUrl: './andar-bahar.component.css'
})
export class AndarBaharComponent {

}
