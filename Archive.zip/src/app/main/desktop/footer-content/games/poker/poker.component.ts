import { Component } from '@angular/core';

@Component({
  selector: 'app-poker',
  templateUrl: './poker.component.html',
  styleUrl: './poker.component.css'
})
export class PokerComponent {

}
