import { Component } from '@angular/core';

@Component({
  selector: 'app-casino',
  templateUrl: './casino.component.html',
  styleUrl: './casino.component.css'
})
export class CasinoComponent {

}
