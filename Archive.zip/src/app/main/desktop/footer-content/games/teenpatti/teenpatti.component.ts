import { Component } from '@angular/core';

@Component({
  selector: 'app-teenpatti',
  templateUrl: './teenpatti.component.html',
  styleUrl: './teenpatti.component.css'
})
export class TeenpattiComponent {

}
