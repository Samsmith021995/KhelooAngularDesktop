import { Component } from '@angular/core';

@Component({
  selector: 'app-football-betting',
  templateUrl: './football-betting.component.html',
  styleUrl: './football-betting.component.css'
})
export class FootballBettingComponent {

}
