import { Component } from '@angular/core';

@Component({
  selector: 'app-cricket-betting',
  templateUrl: './cricket-betting.component.html',
  styleUrl: './cricket-betting.component.css'
})
export class CricketBettingComponent {

}
