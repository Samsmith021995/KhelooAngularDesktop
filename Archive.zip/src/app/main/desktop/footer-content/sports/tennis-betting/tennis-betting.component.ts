import { Component } from '@angular/core';

@Component({
  selector: 'app-tennis-betting',
  templateUrl: './tennis-betting.component.html',
  styleUrl: './tennis-betting.component.css'
})
export class TennisBettingComponent {

}
