import { Component } from '@angular/core';

@Component({
  selector: 'app-online-sports-betting',
  templateUrl: './online-sports-betting.component.html',
  styleUrl: './online-sports-betting.component.css'
})
export class OnlineSportsBettingComponent {

}
