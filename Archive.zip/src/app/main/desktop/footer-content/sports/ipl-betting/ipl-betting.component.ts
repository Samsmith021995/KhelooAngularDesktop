import { Component } from '@angular/core';

@Component({
  selector: 'app-ipl-betting',
  templateUrl: './ipl-betting.component.html',
  styleUrl: './ipl-betting.component.css'
})
export class IplBettingComponent {

}
