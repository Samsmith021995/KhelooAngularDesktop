import { Component } from '@angular/core';

@Component({
  selector: 'app-d-promotional',
  templateUrl: './d-promotional.component.html',
  styleUrl: './d-promotional.component.css'
})
export class DPromotionalComponent {

}
