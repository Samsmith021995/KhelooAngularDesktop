import { Component } from '@angular/core';

@Component({
  selector: 'app-promotion-video',
  templateUrl: './promotion-video.component.html',
  styleUrl: './promotion-video.component.css'
})
export class PromotionVideoComponent {

}
