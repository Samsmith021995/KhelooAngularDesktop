import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawinfo',
  templateUrl: './withdrawinfo.component.html',
  styleUrl: './withdrawinfo.component.css'
})
export class WithdrawinfoComponent {

}
