import { Component } from '@angular/core';

@Component({
  selector: 'app-langstrip',
  templateUrl: './langstrip.component.html',
  styleUrl: './langstrip.component.css'
})
export class LangstripComponent {

}
