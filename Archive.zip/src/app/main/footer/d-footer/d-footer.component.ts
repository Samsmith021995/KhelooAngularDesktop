import { Component } from '@angular/core';

@Component({
  selector: 'app-d-footer',
  templateUrl: './d-footer.component.html',
  styleUrl: './d-footer.component.css'
})
export class DFooterComponent {

}
